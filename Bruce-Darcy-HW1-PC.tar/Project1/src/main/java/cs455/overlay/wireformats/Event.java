package cs455.overlay.wireformats;


/*
An event will be created when

might have to refactor everything I made protocol to be an event instead.
 */
public interface Event {

}
